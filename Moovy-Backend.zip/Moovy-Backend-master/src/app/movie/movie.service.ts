import { BadRequestException, HttpException, Injectable } from '@nestjs/common';
import { MovieRepository } from './movie.repository';
import { MovieEntity } from './entity/movie.entity';
import type { CreateMovieDto } from './dto/create-movie.dto';
import { NoContentException } from './exceptions/no-content-exception';
import { NotFoundException } from './exceptions/not-found-exception';
import type { MoviesBo } from './bo/movies.bo';
import { getFileUrl, sortMovies } from './function/movie.function';

@Injectable()
export class MovieService {
    constructor(
        private readonly movieRepository: MovieRepository,
    ) { }

    async getMovies(isSaved = false): Promise<MoviesBo[]> {
        let moviesData;

        if (isSaved) {
            moviesData = await this.movieRepository.getAllSaved();
        }
        else {
            moviesData = await this.movieRepository.getAll();
        }

        if (moviesData.length === 0) {
            throw new NoContentException();
        }

        const sortedMovies = sortMovies(moviesData);

        const moviesBo = sortedMovies.map((movie) => {
            return {
                ...movie,
                fileUrl: getFileUrl(movie.file),
            };
        });

        return moviesBo;
    }

    async createMovie(data: CreateMovieDto): Promise<MovieEntity> {
        return await this.movieRepository.create(data);
    }

    async updateMovie(id: number, movie: Partial<MovieEntity>): Promise<boolean> {
        return await this.movieRepository.update(id, movie);
    }

    async deleteMovie(id: number): Promise<boolean> {
        return await this.movieRepository.delete(id);
    }

    async getFile(movieId: number): Promise<string> {
        const fileName = await this.movieRepository.getFile(movieId);

        if (!fileName) {
            throw new HttpException('No file uploaded', 404);
        }

        // Gera o link de download
        return getFileUrl(fileName);
    }

    async addFile(movieId: number, file: any): Promise<string> {
        const fs = require('fs');
        const path = require('path');

        const fileName = `${movieId}-${Date.now()}-${file.originalname}`;

        const directory = path.join(__dirname, '..', '..', '..', 'files');
        const filePath = path.join(directory, fileName);

        // Salva o nome do arquivo no banco de dados
        const isSaved = await this.movieRepository.update(movieId, { file: fileName });

        // Verifica se foi salvo
        if (!isSaved) {
            throw new NotFoundException();
        }

        // Cria o diretório caso não exista
        if (!fs.existsSync(directory)) {
            fs.mkdirSync(directory, { recursive: true });
        }

        // Caso já tenha um arquivo com o mesmo ID, exclui o arquivo
        fs.readdir(directory, (err: any, files: any) => {
            if (err) {
                console.log(err);
                return;
            }

            for (const file of files) {
                if (file.includes(`${movieId}-`)) {
                    fs.unlink(path.join(directory, file), (err: any) => {
                        if (err) {
                            console.log(err);
                            return;
                        }
                    });
                }
            }
        });

        // Salva o arquivo no diretório
        fs.writeFile(filePath, file.buffer, (err: any) => {
            if (err) {
                console.log(err);
                return;
            }
        });

        return getFileUrl(fileName);
    }

    async removeFile(id: number): Promise<void> {
        const fileName = await this.movieRepository.getFile(id);

        if (!fileName) {
            throw new HttpException('No file uploaded', 404);
        }

        const fs = require('fs');
        const path = require('path');

        const directory = path.join(__dirname, '..', '..', '..', 'files');
        const filePath = path.join(directory, fileName);

        // Exclui o arquivo do diretório
        fs.unlink(filePath, (err: any) => {
            if (err) {
                console.log(err);
                return;
            }
        });

        // Exclui o nome do arquivo do banco de dados
        const isDeleted = await this.movieRepository.update(id, { file: null });

        if (!isDeleted) {
            throw new HttpException('No file uploaded', 404);
        }
    }
}