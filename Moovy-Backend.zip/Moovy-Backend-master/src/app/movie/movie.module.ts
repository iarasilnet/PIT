import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MovieEntity } from './entity/movie.entity';
import { MovieService } from './movie.service';
import { MovieRepository } from './movie.repository';
import { MovieController } from './movie.controller';

@Module({
  imports: [TypeOrmModule.forFeature([MovieEntity])],
  providers: [MovieService, MovieRepository],
  controllers: [MovieController]
})
export class MovieModule { }