import { HttpException, HttpStatus } from '@nestjs/common';

export class NoContentException extends HttpException {
    constructor() {
        super('No movies found', HttpStatus.NO_CONTENT);
    }
}