export class FileUrlBo {
    fileUrl: string;
}