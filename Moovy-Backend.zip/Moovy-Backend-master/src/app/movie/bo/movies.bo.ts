import { MovieEntity } from "../entity/movie.entity";

export class MoviesBo extends MovieEntity {
    fileUrl: string;
}