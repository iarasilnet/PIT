import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity({ name: 'movies' })

export class MovieEntity {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ nullable: false })
    name: string;

    @Column({ nullable: false })
    image: string;

    @Column({ type: 'float', nullable: false })
    rating: number;

    @Column({ nullable: true })
    file: string;

    @Column({ name: 'is_saved', nullable: false, default: false })
    isSaved: boolean;
}