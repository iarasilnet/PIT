export class CreateMovieDto {
    name: string;
    image: string;
    rating: number;
    review?: string;
    isSaved: boolean = false;
}