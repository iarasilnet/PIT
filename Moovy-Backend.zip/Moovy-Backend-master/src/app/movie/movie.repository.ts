import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { MovieEntity } from './entity/movie.entity';
import type { Repository } from 'typeorm';
import type { CreateMovieDto } from './dto/create-movie.dto';

@Injectable()
export class MovieRepository {
    constructor(
        @InjectRepository(MovieEntity)
        private readonly movieRepository: Repository<MovieEntity>,
    ) { }

    async getAll(): Promise<MovieEntity[]> {
        return await this.movieRepository.find();
    }

    async getAllSaved(): Promise<MovieEntity[]> {
        return await this.movieRepository.find({
            where: {
                isSaved: true,
            },
        });
    }

    async getFile(id: number): Promise<string> {
        return (await this.movieRepository.findOne({ where: { id } }))?.file;
    }

    async create(data: CreateMovieDto): Promise<MovieEntity> {
        return this.movieRepository.save(this.movieRepository.create(data));
    }

    async update(id: number, data: Partial<MovieEntity>): Promise<boolean> {
        return (await this.movieRepository.update(id, data)).affected > 0;
    }

    async delete(id: number): Promise<boolean> {
        return (await this.movieRepository.delete(id)).affected > 0;
    }
}