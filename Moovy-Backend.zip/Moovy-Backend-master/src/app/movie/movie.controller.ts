import { BadRequestException, Body, Controller, Delete, Get, NotFoundException, Param, Patch, Post, UploadedFiles, UseInterceptors } from '@nestjs/common';
import { MovieService } from './movie.service';
import type { CreateMovieDto } from './dto/create-movie.dto';
import { FilesInterceptor } from '@nestjs/platform-express/multer';
import { FileUrlBo } from './bo/file-url.bo';
import type { MovieEntity } from './entity/movie.entity';

@Controller('movies')
export class MovieController {
    constructor(private readonly movieService: MovieService) { }

    @Get()
    async getAll(): Promise<MovieEntity[]> {
        return await this.movieService.getMovies();
    }

    @Get('saved')
    async getAllSaved(): Promise<MovieEntity[]> {
        return this.movieService.getMovies(true);
    }

    @Get(':id/file')
    async getFile(@Param('id') id: number): Promise<FileUrlBo> {
        return {
            fileUrl: await this.movieService.getFile(id),
        }
    }

    @Post()
    async createMovie(@Body() data: CreateMovieDto) {
        return await this.movieService.createMovie(data);
    }

    @Post(':id/file')
    @UseInterceptors(FilesInterceptor('file', 1))
    async addFile(
        @Param('id') movieId: number,
        @UploadedFiles() file: any[]
    ): Promise<FileUrlBo> {
        if (!file || file.length === 0) {
            throw new BadRequestException('No file uploaded');
        }

        const isSaved = await this.movieService.addFile(movieId, file[0]);

        if (isSaved) {
            return {
                fileUrl: await this.movieService.getFile(movieId),
            };
        }
    }

    @Patch(':id/save')
    async saveMovie(@Param('id') id: number) {
        const isUpdated = await this.movieService.updateMovie(id, { isSaved: true });

        if (!isUpdated) {
            throw new NotFoundException();
        }
    }

    @Patch(':id/unsave')
    async unsaveMovie(@Param('id') id: number) {
        const isUpdated = await this.movieService.updateMovie(id, { isSaved: false });

        if (!isUpdated) {
            throw new NotFoundException();
        }
    }

    @Delete(':id')
    async deleteMovie(@Param('id') id: number) {
        const isDeleted = await this.movieService.deleteMovie(id);

        if (!isDeleted) {
            throw new NotFoundException();
        }
    }

    @Delete(':id/file')
    async removeFile(@Param('id') id: number) {
        return await this.movieService.removeFile(id);
    }
}