import type { MovieEntity } from "../entity/movie.entity";

export function sortMovies(movies: MovieEntity[]): MovieEntity[] {
    movies.sort((a, b) => {
        if (a.name < b.name) {
            return -1;
        }

        if (a.name > b.name) {
            return 1;
        }

        return 0;
    });

    return movies;
}

export function getFileUrl(fileName: string): string {
    if (!fileName) {
        return null;
    }
    return `http://192.168.15.105:3000/files/${fileName}`;
}