import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';

@Injectable()
export class LoggerMiddleware implements NestMiddleware {
    use(req: Request, res: Response, next: NextFunction) {
        const { method, originalUrl } = req;
        const start = Date.now();

        // Ouve o evento de finalização da resposta para calcular o tempo de resposta
        res.on('finish', () => {
            const statusCode = res.statusCode;
            const duration = Date.now() - start;
            console.log(
                `${method} ${originalUrl} ${statusCode} - ${duration}ms`,
            );
        });

        next();
    }
}
