import { createContext } from "react";
import type { Movie } from "../models/movie-model";

export const MovieContext = createContext({
    movies: [] as Movie[],
    setMovies: (movies: Movie[]) => { },

    savedMovies: [] as Movie[],
    setSavedMovies: (movies: Movie[]) => { },

    selectedPage: 1,
    setSelectedPage: (page: number) => { },

    showModal: false,
    setShowModal: (show: boolean) => { },

    selectedMovie: null as Movie | null,
    setSelectedMovie: (movie: Movie | null) => { }
});