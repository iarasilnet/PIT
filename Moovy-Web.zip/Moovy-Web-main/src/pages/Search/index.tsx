import { useEffect, useRef, useState } from "react";
import { Container, Section } from "./styles";
import { Input } from "../../components/Input";
import { Header } from "../../components/Header";
import { Title } from "../../components/Title";
import { MoviesList } from "../../components/MoviesList";
import { useMovieContext } from "../../hooks/useMovieContext";
import { get } from "../../services/movie-service";
import { NoContent } from "../../components/NoContent";
import type { Movie } from "../../models/movie-model";

export function Search() {
    const { movies, setMovies } = useMovieContext();
    const searchInput = useRef<HTMLInputElement>(null);
    const [filteredMovies, setFilteredMovies] = useState<Movie[]>([]);

    async function loadMovies() {
        try {
            const data = await get();
            setMovies(data);
            setFilteredMovies(data);
        } catch (error) {
            console.error('Erro ao carregar dados:', error);
        }
    }

    const search = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFilteredMovies(movies.filter(movie => movie.name.toLowerCase().includes(e.target.value.toLowerCase())));
    };

    useEffect(() => {
        loadMovies();
    }, []);

    return (
        <Container>
            <Header />

            <Section>
                <Title
                    text="Procurar"
                />

                <Input
                    ref={searchInput}
                    placeholder="Procurar por nome do filme"
                    type="text"
                    onChange={search}
                />

                {
                    filteredMovies.length === 0 ? (
                        <NoContent
                            text='Nenhum filme encontrado :('
                        />
                    ) : (
                        <MoviesList
                            movies={filteredMovies}
                        />
                    )
                }
            </Section>
        </Container>
    )
}