import styled from "styled-components";

export const Container = styled.div`
    width: 100%;

    display: flex;
    flex-direction: column;
`;

export const Section = styled.div`
    display: flex;
    flex-direction: column;

    width: 70%;
    margin: 0 auto;
`;

export const Title = styled.h1`
    color: #8257e5;
`;