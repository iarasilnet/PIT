import { useEffect } from "react";
import { getSaved } from "../../services/movie-service";
import { MoviesList } from "../../components/MoviesList";
import { Container, Section } from "./styles";
import { Header } from "../../components/Header";
import { Title } from "../../components/Title";
import { useMovieContext } from "../../hooks/useMovieContext";
import { NoContent } from "../../components/NoContent";

export function MyLibrary() {
    const { savedMovies, setSavedMovies } = useMovieContext();

    async function loadSavedMovies() {
        try {
            // setLoading(true);
            const data = await getSaved();
            setSavedMovies(data);
        } catch (error) {
            console.error('Erro ao carregar dados:', error);
        } finally {
            // setLoading(false);
        }
    }

    useEffect(() => {
        loadSavedMovies();
    }, []);

    return (
        <Container>
            <Header />

            <Section>
                <Title
                    text="Minha Biblioteca"
                />

                {
                    savedMovies.length === 0 ? (
                        <NoContent
                            text='Aparentemente não há filmes salvos na sua biblioteca! Procure por um filme que você tenha assistido e salve-o para vê-lo aqui.'
                        />
                    ) : (
                        <MoviesList
                            movies={savedMovies}
                        />
                    )
                }
            </Section>
        </Container>
    )
}