import styled from "styled-components";
import type { ButtonColors } from ".";

export const Container = styled('button') <{ color: ButtonColors }>`
    background-color: ${({ color }) => color === 'primary' ? '#0ACF83' : color === 'secondary' ? '#FE6D8E' : '#A1A1A1'};
    color: #fff;
    border: 0;
    border-radius: 12px;
    padding: 0.5rem 1rem;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    transition: filter 0.2s;

    &:hover {
        filter: brightness(0.9);
    }
`;