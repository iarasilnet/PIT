import type { ButtonHTMLAttributes } from "react";
import { Container } from "./styles";

export type ButtonColors = 'primary' | 'secondary' | 'tertiary';

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
    // a cor padrao é a primaria
    color?: ButtonColors;
}

export function Button({ color = 'primary', ...rest }: ButtonProps) {
    return (
        <Container
            color={color ?? 'primary'}
            {...rest}
        >
            {rest.children}
        </Container>
    )
}