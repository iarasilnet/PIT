import { Container, Text } from "./styles";

export function Title({ text }: { text: string }) {
    return (
        <Container>
            <Text>{text}</Text>
        </Container>
    )
}