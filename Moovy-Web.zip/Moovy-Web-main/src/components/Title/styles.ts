import styled from "styled-components";

export const Container = styled.div`
    margin-bottom: 1rem;
`;

export const Text = styled.h2`
    font-size: 1.4rem;
    font-weight: 400;
    margin-bottom: 1rem;
`;