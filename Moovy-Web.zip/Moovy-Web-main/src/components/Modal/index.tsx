import { Button } from "../Button";
import { ButtonArea, Container, Content, Description, Title } from "./styles";
import { unsave } from "../../services/movie-service";
import { useMovieContext } from "../../hooks/useMovieContext";

export function Modal() {
    const {
        savedMovies, setSavedMovies,
        showModal, setShowModal,
        selectedMovie, setSelectedMovie
    } = useMovieContext();

    async function unsaveMovie() {
        try {
            const success = await unsave(selectedMovie!.id);

            if (success) {
                const newMovies = savedMovies.filter(m => m.id !== selectedMovie!.id);
                setSavedMovies(newMovies);
            }
        } catch (error) {
            console.error('Erro ao remover filme:', error);
        } finally {
            closeModal();
        }
    }

    function closeModal() {
        setShowModal(false);
        setSelectedMovie(null);
    }

    if (!showModal) {
        return null;
    }

    return (
        < Container >
            <Content>
                <Title>
                    Remover da sua biblioteca
                </Title>

                <Description>
                    Tem certeza que deseja remover o filme {selectedMovie!.name} da sua biblioteca?
                </Description>

                <ButtonArea>
                    <Button
                        onClick={unsaveMovie}
                        color='secondary'
                    >
                        Remover
                    </Button>

                    <Button
                        onClick={closeModal}
                        color='tertiary'
                    >
                        Cancelar
                    </Button>
                </ButtonArea>
            </Content>
        </Container >
    );
}