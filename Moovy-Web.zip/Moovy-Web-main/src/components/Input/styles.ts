import styled from "styled-components";

export const Container = styled.div`
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;

    background-color: #fff;

    border-radius: 16px;

    gap: 1rem;

    margin-bottom: 2rem;
`;

export const Content = styled.input`
    width: 100%;
    padding: 0.5rem 1rem;

    outline: none;
    border: none;
    border-radius: inherit;

    font-size: 1rem;

    background-color: inherit;
`;