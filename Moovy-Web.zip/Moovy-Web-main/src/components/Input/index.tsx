import { forwardRef } from "react";
import { Container, Content } from "./styles";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSearch } from "@fortawesome/free-solid-svg-icons";

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> { }

export const Input = forwardRef<HTMLInputElement, InputProps>(({ onChange, ...rest }, ref) => {
    return (
        <Container>
            <Content
                ref={ref}
                {...rest}
                onChange={onChange}
            />

            <FontAwesomeIcon
                icon={faSearch}
                size="1x"
                color="#A1A1A1"
                style={{ paddingRight: '1rem' }}
            />
        </Container>
    );
});