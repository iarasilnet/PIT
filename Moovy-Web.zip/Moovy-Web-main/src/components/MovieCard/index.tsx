import type { Movie } from "../../models/movie-model";
import { Container, Image, Rating, Info, Title } from "./styles";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faStar } from '@fortawesome/free-solid-svg-icons';
import { Button } from "../Button";
import { useMovieContext } from "../../hooks/useMovieContext";
import { save } from "../../services/movie-service";

export function MovieCard({ movie }: { movie: Movie }) {
    const { savedMovies, setSavedMovies, setShowModal, setSelectedMovie } = useMovieContext();

    const isSaved = savedMovies.some((savedMovie) => savedMovie.id === movie.id);

    function openModal() {
        setSelectedMovie(movie);
        setShowModal(true);
    }

    async function saveMovie(movie: Movie) {
        try {
            // setLoading(true);
            const isSaved = await save(movie.id);

            if (isSaved) {
                setSavedMovies([...savedMovies, movie]);
            }
        } catch (error) {
            console.error('Erro ao carregar dados:', error);
        } finally {
            // setLoading(false);
        }
    }

    return (
        <Container>
            <Image
                src={movie.image}
                alt={movie.name}
            />

            <Info>
                <Title>{movie.name}</Title>

                <Info
                    style={{
                        gap: '0.4rem',
                        margin: '1rem 0'
                    }}
                >
                    <FontAwesomeIcon
                        icon={faStar}
                        color="gold"
                    />

                    <Rating>{movie.rating.toFixed(1)}</Rating>
                </Info>

            </Info>

            <Button
                color={isSaved ? 'secondary' : 'primary'}
                onClick={() => isSaved ? openModal() : saveMovie(movie)}
            >
                {isSaved ? 'Remover' : 'Adicionar'}
            </Button>
        </Container>
    );
}