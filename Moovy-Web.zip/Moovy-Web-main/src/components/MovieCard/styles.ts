import styled from "styled-components";

export const Container = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center ;

    border-radius: 12px;

    padding: 1rem;
    
    background-color: #fff;
`;

export const Image = styled.img`
    height: 300px;
    width: 200px;

    border: 1px solid #A1A1A1;
    border-radius: 12px;

    object-fit: cover;
`;

export const Info = styled.section`
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;

    gap: 1rem;
`;

export const Title = styled.h3`
    margin: 0;
    font-size: 1.2rem;
    font-weight: normal;
`;

export const Rating = styled.p`
    margin: 0;
    font-size: 1rem;
`;