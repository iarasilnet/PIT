import styled from "styled-components";

export const List = styled.ul`
    display: grid;
    list-style: none;
    
    padding: 0;
    gap: 1rem;

    grid-template-columns: repeat(3, 1fr);
`;