import { Movie } from '../../models/movie-model';
import { Modal } from '../Modal';
import { MovieCard } from '../MovieCard';
import { List } from './styles';

export function MoviesList({ movies }: { movies: Movie[] }) {
    return (
        <>
            <Modal />

            <List>
                {movies.map((movie) => (
                    <li key={movie.id}>
                        <MovieCard
                            movie={movie}
                        />
                    </li>
                ))}
            </List>
        </>
    );
}