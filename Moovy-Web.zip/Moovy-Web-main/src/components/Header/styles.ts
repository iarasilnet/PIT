import styled from "styled-components";

export const Container = styled.div`
    width: 100%;

    display: flex;
    flex-direction: row;
    align-items: center;

    margin-bottom: 2rem;

    background-color: #e5e5e5;
`;

export const Title = styled.h1`
    font-size: 2.2rem;
    font-weight: 600;

    margin-right: 9rem;

    color: #F2911B;
`;

export const Option = styled.button`
    font-size: 1rem;
    font-weight: bold;

    margin-right: 1.5rem;

    color: #F2911B;
    background-color: transparent;
    border: none;

    cursor: pointer;
`;