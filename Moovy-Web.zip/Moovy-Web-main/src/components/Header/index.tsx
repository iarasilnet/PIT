import { useMovieContext } from "../../hooks/useMovieContext";
import { Container, Title } from "./styles";
import { Option } from "./styles";

export function Header() {
    const { setSelectedPage } = useMovieContext();

    function handleSearch() {
        setSelectedPage(1);
    }

    function handleMyLibrary() {
        setSelectedPage(2);
    }

    return (
        <Container>
            <Title>Moovy</Title>

            <Option
                onClick={handleSearch}
            >Procurar</Option>
            <Option
                onClick={handleMyLibrary}
            >Minha biblioteca</Option>
        </Container>
    );
}