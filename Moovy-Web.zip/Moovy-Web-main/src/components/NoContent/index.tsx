import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSearch } from '@fortawesome/free-solid-svg-icons';
import { Container, ParentContainer, Title } from "./styles";

type NoContentProps = {
    text: string;
}

export function NoContent({ text }: NoContentProps) {
    return (
        <ParentContainer>
            <Container>
                <FontAwesomeIcon
                    icon={faSearch}
                    size='2x'
                    color='#A1A1A1'
                />
                <Title>
                    {text}
                </Title>
            </Container>
        </ParentContainer>
    );
}