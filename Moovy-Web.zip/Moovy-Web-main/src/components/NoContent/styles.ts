import styled from "styled-components";

export const ParentContainer = styled.div`
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh; // Ocupa toda a altura da tela
`;

export const Container = styled.div`
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;

    height: auto;
    max-width: 50%;
    max-height: 70vh;

    gap: 1.5rem;
`;

export const Title = styled.h1`
    font-size: 1.2rem;
    font-weight: 300;
    text-align: center;
    color: #A1A1A1;
`;