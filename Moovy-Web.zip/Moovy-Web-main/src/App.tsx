import { useState } from "react";
import { MyLibrary } from "./pages/MyLibrary";
import type { Movie } from "./models/movie-model";
import { MovieContext } from "./contexts/movie-context";
import { Search } from "./pages/Search";


function App() {
    const [movies, setMovies] = useState<Movie[]>([]);
    const [savedMovies, setSavedMovies] = useState<Movie[]>([]);
    const [selectedPage, setSelectedPage] = useState(2);
    const [showModal, setShowModal] = useState(false);
    const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);

    return (
        <MovieContext.Provider
            value={{
                movies, setMovies,
                savedMovies, setSavedMovies,
                selectedPage, setSelectedPage,
                showModal, setShowModal,
                selectedMovie, setSelectedMovie
            }}
        >
            {selectedPage === 1 ? <Search /> : <MyLibrary />}
        </MovieContext.Provider>
    );
}

export default App;