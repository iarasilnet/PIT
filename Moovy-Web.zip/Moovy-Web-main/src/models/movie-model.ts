export interface Movie {
    id: number;
    name: string;
    rating: number;
    image: string;
}