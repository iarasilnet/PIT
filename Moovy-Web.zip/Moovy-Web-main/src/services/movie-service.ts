const API_URL = 'http://localhost:3000';

export async function get() {
    try {
        const response = await fetch(`${API_URL}/movie`);

        console.log(response.status);

        if (!response.ok) {
            throw new Error('Failed to fetch movies');
        }

        if (response.status === 204) {
            return [];
        }

        return await response.json();
    } catch (error) {
        console.error(error);
        return [];
    }
}

export async function getSaved() {
    try {
        const response = await fetch(`${API_URL}/movie/saved`);

        console.log(response.status);

        if (!response.ok) {
            throw new Error('Failed to fetch saved movies');
        }

        if (response.status === 204) {
            return [];
        }

        return await response.json();
    } catch (error) {
        console.error(error);
        return [];
    }
}

export async function save(id: number) {
    try {
        const response = await fetch(`${API_URL}/movie/${id}/save`, {
            method: 'PATCH',
        });

        if (!response.ok) {
            throw new Error('Failed to save movie');
        }

        return true;
    } catch (error) {
        console.error(error);
        return false;
    }
}

export async function unsave(id: number) {
    try {
        const response = await fetch(`${API_URL}/movie/${id}/unsave`, {
            method: 'PATCH',
        });

        if (!response.ok) {
            throw new Error('Failed to unsave movie');
        }

        return true;
    } catch (error) {
        console.error(error);
        return false;
    }
}